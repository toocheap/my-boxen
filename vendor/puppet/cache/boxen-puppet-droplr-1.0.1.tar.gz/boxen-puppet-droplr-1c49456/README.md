# droplr Puppet Module for Boxen

## Usage

```puppet
include droplr
```

## Required Puppet Modules

* boxen
* stdlib

